Imports System.Security.Principal
Imports AccuDemo


Namespace AccuDemo


    Public Class ExceptionFilter
        Shared Sub ShowProblem()
            Dim op As ImpersonatingOperation
            op = New ImpersonatingOperation

            Try
                op.Go()

            Catch When FilterRoutine_Trust(op) = True
                System.Console.WriteLine("Catch Block: Trusted = " + op.Trusted.ToString())
            End Try

        End Sub

        Shared Sub ShowBeltAndBraces()
            Dim op As ImpersonatingOperation
            op = New ImpersonatingOperation

            Try
                op.BeltAndBraces()

            Catch When FilterRoutine_Trust(op) = True
                System.Console.WriteLine("Catch Block: Trusted = " + op.Trusted.ToString())
            End Try

        End Sub

        Shared Sub ShowPartialFix()
            Dim op As ImpersonatingOperation
            op = New ImpersonatingOperation

            Try
                op.Go(True)

            Catch When FilterRoutine_Identity() = True
                System.Console.WriteLine("Catch Block: " + WindowsIdentity.GetCurrent().Name)
            End Try
        End Sub

        Shared Sub ShowBrokenFix()
            Dim op As ImpersonatingOperation
            op = New ImpersonatingOperation

            Try
                op.Go(False)

            Catch When FilterRoutine_Identity() = True
                System.Console.WriteLine("Catch Block: " + WindowsIdentity.GetCurrent().Name)
            End Try
        End Sub

        Shared Function FilterRoutine_Identity() As Boolean

            System.Console.WriteLine("Filter Routine: " + WindowsIdentity.GetCurrent().Name)

            FilterRoutine_Identity = True

        End Function

        Shared Function FilterRoutine_Trust(ByVal op As ImpersonatingOperation) As Boolean

            System.Console.WriteLine("Filter Routine: Trusted = " + op.Trusted.ToString())

            FilterRoutine_Trust = True

        End Function

    End Class

End Namespace

