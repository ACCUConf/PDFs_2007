// ManagedCpp.h

#pragma once

using namespace System;

namespace AccuDemo {

	public ref class ManagedCpp
	{
	public:
		static void ThrowManagedInt(int i)
		{
			throw gcnew int(i);
		}

		static void ThrowUnmanagedInt(int i)
		{
			throw new int(i);
		}

		static int Divide(int x, int y)
		{
			return x/y;
		}
	};
}
