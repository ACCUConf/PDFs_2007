using System;
using System.Collections.Generic;
using System.Text;

namespace AccuDemo
{
    public class NonWrapping
    {
        public static void CallCpp()
        {
            try
            {
                ManagedCpp.ThrowManagedInt(42);
            }
            catch (System.Runtime.CompilerServices.RuntimeWrappedException rwe)
            {
                Console.WriteLine("CallCpp: Runtime Wrapped Exception caught: " + rwe.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("CallCpp: Exception caught: " + e.Message);
            }
            catch
            {
                Console.WriteLine("CallCpp: Catch-all");
                throw;
            }
        }
    }
}
